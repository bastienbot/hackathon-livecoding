const rp = require('request-promise');

const { API_KEY, API_URL } = process.env;

async function query(event) {
  const options = {
    'method': 'POST',
    'url': API_URL,
    'headers': {
      'Authorization': `Bearer ${API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      records: [
        {
          fields: {
            email: event.email,
            from: event.from,
            campus: event.campus,
            idea: event.idea,
            photo: event.photo,
          }
        }
      ]
    })

  };
  return rp(options)
  .then(response => { 
    return response
  });
};

module.exports.handler = async (event) => {
  return query(event)
}

// // Uncomment this code below to test your function
// (async function() {
//   const event = {
//     email: "event.email",
//     from: "event.from",
//     campus: "event.campus",
//     idea: "event.idea",
//     photo: "event.photo",
//   }
//   return query(event)
// })();
